Parameters:

config_id
baseUrl

```
/v1/chat/completions
```

```json
{
    "config_id": "bedrock",
    "messages": [
        {
            "role": "user",
            "content": "Hello! What can you do for me?"
        }
    ]
}
```
